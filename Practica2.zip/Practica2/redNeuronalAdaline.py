# -*- coding: utf-8 -*-
"""
Created on Sun Mar 19 12:18:02 2023

@author: Adrian
"""



import numpy as np

def hardlimit(n):
    at = np.zeros(4)
    for i in range(len(b)):
        if n[i]<0:
            at[i] = -1
        else: 
            at[i] = 1
        return at
    
    
w = np.load('w.npy')
b = np.load('b.npy')

w= np.transpose(w)

p = np.load('prueba.npy')

for i in range(len(p)):
    n = hardlimit(np.dot(w,p[i]) + b)
    print(n)