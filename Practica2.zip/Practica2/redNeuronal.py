# -*- coding: utf-8 -*-
"""
Created on Thu Mar 16 23:23:38 2023

@author: Adrian
"""
import numpy as np
from skimage import data, io, color, morphology,measure


def sigmoide(n):
    a=1/(1+np.exp(-n))
    return a

w1 = np.load('w1.npy')
w2 = np.load('w2.npy')

b1 = np.load('b1.npy')
b2 = np.load('b2.npy')

#w1 = np.transpose(w1)
at = np.zeros(10)
#w2 = np.transpose(w2)

def hardlimit(n):
    at = np.zeros(len(n))
    for i in range(len(n)):
        if n[i]<0:
            at[i] = 0
        else: 
            at[i] = 1
        return at
def sacarMomentos(imagen):
    ima = io.imread(imagen)
    M=measure.moments(ima)
    C=(M[1,0]/M[0,0],M[0,1]/M[0,0])
    mu=measure.moments_central(ima,C)
    nu=measure.moments_normalized(mu)
    return measure.moments_hu(nu)

prueba = np.load('prueba.npy')


a = np.zeros(4)
n = np.zeros(4)

a2 = np.zeros(4)
a = []
for i in range(len(prueba)):
    #print()
    n1=w1@prueba[i]+b1
    #print(n1)
    a1=sigmoide(n1)
    n2=w2@a1+b2
    a2 = hardlimit(n2)
    print(a2)
    # a.append(n2)
    # print(n2)
    # for j in range(len(n2)):
    #         if n2[i] < 0:
    #             a2[i] = -1
    #         else:
    #             a2[i] = 1
    #print(a2)

# for i in range(len(prueba)):
#     n = np.dot(w,prueba[i]) + b
#     #print(len(n))
#     # for j in range(len(n)):
#     #     if n[i] < 0:
#     #         a[i] = 0
#     #     else:
    #         a[i] = 1