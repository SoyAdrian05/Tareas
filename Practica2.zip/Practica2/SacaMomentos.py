# -*- coding: utf-8 -*-
"""
Created on Wed Mar 15 09:52:04 2023

@author: Saul
"""

from skimage import data, io, color, morphology,measure
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
import mpl_toolkits.mplot3d
import os

plt.close("all")
def sacarMomentos(imagen):
    ima = io.imread(imagen)
    M=measure.moments(ima)
    C=(M[1,0]/M[0,0],M[0,1]/M[0,0])
    mu=measure.moments_central(ima,C)
    nu=measure.moments_normalized(mu)
    return measure.moments_hu(nu)
    
a = []
ejemplo_dir = 'D://Adrian/Escuela/UPIITA/Reconocimiento de Patrones/Practica2/imagenes/ima'
with os.scandir(ejemplo_dir) as ficheros:
    for fichero in ficheros:
        a.append(fichero.name)
    
prueba = []        
for i in range(len(a)):
    hu = sacarMomentos('D://Adrian/Escuela/UPIITA/Reconocimiento de Patrones/Practica2/imagenes/ima/' + a[i])
    prueba.append(hu)
            

# no_se = sacarMomentos('D://Adrian/Escuela/UPIITA/Reconocimiento de Patrones/NeuronaCesar/Numeros_Placas/Numeros_Placas/num_0_5.bmp')
# no_se2 = sacarMomentos('D://Adrian/Escuela/UPIITA/Reconocimiento de Patrones/Practica2/imagenes/num0/numero0APR.bmp')

# #momentos_deHu_Num0 = np.zeros((6,7)) 
# momentos_deHu_Num0 = np.zeros(7)
    
# for i in range(len(a)):
#     obj3=io.imread(ejemplo_dir + "/" + a[i])
#     plt.figure()
#     plt.imshow(obj3,cmap='gray')
#     M=measure.moments(obj3)
#     C=(M[1,0]/M[0,0],M[0,1]/M[0,0])
#     mu=measure.moments_central(obj3,C)
#     nu=measure.moments_normalized(mu)
#     hu=measure.moments_hu(nu)
#     #momentos_deHu_Num0[i] = hu
# # plt.close('all')
# # obj3=io.imread('imagenes/numero1COE2.bmp')
# # plt.figure()
# # plt.imshow(obj3,cmap='gray')
# hu = np.transpose(hu)
# ## Momentos de Hu
# np.array((momentos_deHu_Num0))


# [2.77576081e-03 7.08335347e-06 9.14352487e-10 6.27609333e-10
#  4.74463050e-19 1.65753729e-12 3.03810617e-20]

# [2.93305088e-03 7.94972126e-06 1.23621716e-09 8.66872657e-10
#  8.95663880e-19 2.42323720e-12 5.56034577e-20]

# [3.14589662e-03 9.16010114e-06 1.82260013e-09 1.29012560e-09
#  1.97382490e-18 3.86043902e-12 1.33093574e-19]

# [2.98868848e-03 8.29212837e-06 6.59935757e-10 4.15078924e-10
#  2.16441647e-19 1.18028628e-12 1.86484686e-20]