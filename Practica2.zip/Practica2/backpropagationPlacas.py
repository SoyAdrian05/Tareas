# -*- coding: utf-8 -*-
"""
Created on Sat Mar 18 10:53:43 2023

@author: Adrian
"""
import numpy as np
import matplotlib.pyplot as plt
#_____________________________________________________________________________________________________________________________________
#--------------------------------------------FUNCIONES---------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------
def sigmoide(n):
    a=1/(1+np.exp(-n))
    return a
def unirMomentos():
    hu_0 = np.load("p_0.npy") 
    hu_1 = np.load("p_1.npy") 
    hu_2 = np.load("p_2.npy") 
    hu_3 = np.load("p_3.npy") 
    hu_4 = np.load("p_4.npy") 
    hu_5 = np.load("p_5.npy") 
    hu_6 = np.load("p_6.npy") 
    hu_7 = np.load("p_7.npy") 
    hu_8 = np.load("p_8.npy") 
    hu_9 = np.load("p_9.npy") 

    for i in range(len(p)):
        if i<10:
            p[i] = hu_0[i]
            
        elif i>9 and i<20:
            p[i] = hu_1[i-10]
            
        elif i>19 and i<30:
            p[i] = hu_2[i-20]   
            
        elif i>29 and i<40:
            p[i] = hu_3[i-30]
            
        elif i>39 and i<50:
            p[i] = hu_4[i-40]    
            
        elif i>49 and i<60:
            p[i] = hu_5[i-50]
            
        elif i>59 and i<70:
            p[i] = hu_6[i-60]    
            
        elif i>69 and i<80:
            p[i] = hu_7[i-70]
            
        elif i>79 and i<90:
            p[i] = hu_8[i-80]    
            
        else:
            p[i] = hu_9[i-90]
#---------------------------------------------------------------------------------------------------------------------------------------
#_____________________________________________BACKPROPAGATION__________________________________________________________________________
# DE 7 ENTRADAS A 10 NEURONAS CON 3 SALIDAS

#W1 = 7X10, B1 = 10 Pentrada = 7 
#W2 = 10X4, B2 = 4

#P 7X1

w1 = np.random.rand(7,10)
b1 = np.random.rand(10)
w1 = np.transpose(w1)


w2 = np.random.rand(10,4)
b2 = np.random.rand(4)
w2 = np.transpose(w2)

p = np.zeros((100,7))

p = np.load('p.npy')    

import numpy as np
t = np.zeros((100,4))

for i in range(len(t)):
    if i<10:
        t[i] = [-1,-1,-1,-1]
    elif i>9 and i<20:
        t[i] = [-1,-1,-1,1]
    elif i>19 and i<30:
        t[i] = [-1,-1,1,-1]
    elif i>29 and i<40:
        t[i] = [-1,-1,1,1]
    elif i>39 and i<50:
        t[i] = [-1,1,-1,-1] 
    elif i>49 and i<60:
        t[i] = [-1,1,-1,1]
    elif i>59 and i<70:
        t[i] = [-1,1,1,-1]    
    elif i>69 and i<80:
        t[i] = [-1,1,1,1]
    elif i>79 and i<90:
        t[i] = [1,-1,-1,-1]   
    else:
        t[i] = [1,-1,-1,1]
        
        
alpha = 0.1

epocas = 100000

ERROR = np.zeros(epocas*p.shape[1])
aprendizaje = []
for j in range(epocas):
    suma=0
    for i in range(len(p)):
        a0 = p[i]
        n1 = w1@a0 + b1
        a1 = sigmoide(n1)
        n2 = w2@a1 + b2
        #a2 = np.where(n2<0,-1,1)
        a2 = sigmoide(n2)
        error = t[i] - a2
        
        
        df2=np.multiply((1-a2),(a2))
        s2=(-2)*df2*error
        df1=np.diagflat(np.multiply((1-a1),(a1))) 
        s1 = (np.dot(np.dot(df1,np.transpose(w2)),s2))
        
        
        w2 = w2 - (alpha*np.outer(s2,a1))
        b2 = b2 - (alpha*s2)
        
        w1 = w1 - (alpha*np.outer(s1,a0))
        b1 = b1 - (alpha*s1)
        et=np.sum((np.sqrt(error**2))/100)
        suma=et+suma
    aprendizaje.append(suma)

plt.figure()
plt.plot(aprendizaje)
        #w1=w1-(alpha*s1)
        # b1=b1-(alpha*s1)
        # w2=w2-(alpha*s2*a1.T)
        # b2=b2-(alpha*s2)        
        
        # for i in range(len(n1)):
        #     n1[i] = n1[i] + b1[i] 
# k = 0
# #----------------------------------------------------------
# for j in range (epocas): 
#     for i in range(p.shape[1]):
#         # a0=p[i]
#         # a0 = a0[:,np.newaxis]
#         n1=w1@p[i]+b1
#         a1=sigmoide(n1)
#         n2=w2@a1+b2
#         a2=sigmoide(n2)
#         error=t[i]-a2 
       
#         #ERROR[k] = error
#         df2=np.multiply((1-a2),(a2))
#         s2=(-2)*df2*error
#         df1=np.diagflat(np.multiply((1-a1),(a1))) 
#         s1=(df1.dot(w2.T)).dot(s2) 
        
#         w1=w1-(alpha*s1*a0.T)
#         b1=b1-(alpha*s1)
#         w2=w2-(alpha*s2*a1.T)
#         b2=b2-(alpha*s2)
#         k = k +1