# -*- coding: utf-8 -*-
"""
Created on Wed Mar 15 12:00:15 2023

@author: Adrian
"""

#RED NEURONAL ENTRENAMIENTO

import numpy as np
import matplotlib.pyplot as plt

def unirMomentos():
    hu_0 = np.load("p_0.npy") 
    hu_1 = np.load("p_1.npy") 
    hu_2 = np.load("p_2.npy") 
    hu_3 = np.load("p_3.npy") 
    hu_4 = np.load("p_4.npy") 
    hu_5 = np.load("p_5.npy") 
    hu_6 = np.load("p_6.npy") 
    hu_7 = np.load("p_7.npy") 
    hu_8 = np.load("p_8.npy") 
    hu_9 = np.load("p_9.npy") 

    for i in range(len(p)):
        if i<10:
            p[i] = hu_0[i]
            
        elif i>9 and i<20:
            p[i] = hu_1[i-10]
            
        elif i>19 and i<30:
            p[i] = hu_2[i-20]
            
        elif i>29 and i<40:
            p[i] = hu_3[i-30]
            
        elif i>39 and i<50:
            p[i] = hu_4[i-40]    
            
        elif i>49 and i<60:
            p[i] = hu_5[i-50]
            
        elif i>59 and i<70:
            p[i] = hu_6[i-60]    
            
        elif i>69 and i<80:
            p[i] = hu_7[i-70]
            
        elif i>79 and i<90:
            p[i] = hu_8[i-80]    
            
        else:
            p[i] = hu_9[i-90]
    

# p = p[:]
def hardlimit(n):
    for i in range(len(b)):
        if n[i]<0:
            at[i] = 0
        else: 
            at[i] = 1
        return at

def calculaAlpha(p):
    R=0
    for i in range(len(p)):
        R=R+0.25*np.outer(p[i],np.transpose(p[i]))
        eigenvalor, vector=np.linalg.eig(R)
        lamdamax=max(eigenvalor)
        return 0.99/(4*lamdamax)


np.seterr(invalid='ignore')
neuronas = 4
entradas = 7

p =np.zeros((100,entradas))
w = np.random.rand(entradas,neuronas)

tasign = np.array(([0,0,0,0,0,0,0,0,0,1],[0,0,0,0,0,0,0,0,1,0], [0,0,0,0,0,0,0,1,0,0], [0,0,0,0,0,0,1,0,0,0], [0,0,0,0,0,1,0,0,0,0], [0,0,0,0,1,0,0,0,0,0], [0,0,0,1,0,0,0,0,0,0], [0,0,1,0,0,0,0,0,0,0], [0,1,0,0,0,0,0,0,0,0], [1,0,0,0,0,0,0,0,0,0]))

t = np.zeros((100,4))



for i in range(len(t)):
    if i<10:
        t[i] = [-1,-1,-1,-1]
    elif i>9 and i<20:
        t[i] = [-1,-1,-1,1]
    elif i>19 and i<30:
        t[i] = [-1,-1,1,-1]
    elif i>29 and i<40:
        t[i] = [-1,-1,1,1]
    elif i>39 and i<50:
        t[i] = [-1,1,-1,-1] 
    elif i>49 and i<60:
        t[i] = [-1,1,-1,1]
    elif i>59 and i<70:
        t[i] = [-1,1,1,-1]    
    elif i>69 and i<80:
        t[i] = [-1,1,1,1]
    elif i>79 and i<90:
        t[i] = [1,-1,-1,-1]   
    else:
        t[i] = [1,-1,-1,1]
b = np.random.rand(neuronas)
at = np.zeros(neuronas)

p = np.load("p.npy")

epocas = 100000


# = calculaAlpha(p)
alpha = 0.01
aprendizaje = []

for k in range(epocas):
    suma=0
    for i in range(len(p)):
        #print()
        a = (np.dot(np.transpose(w), p[i]) + b)
        #print("saida -->", a)
        #print("target -->", t[i])
        e = t[i] - a
        #print(e)
        w = w + np.outer(p[i],e)*alpha
        b = b + e*alpha   
        et=np.sum((np.sqrt(e**2))/100)
        suma=et+suma
    aprendizaje.append(suma)
        #print("\n", b)
plt.figure()
plt.plot(aprendizaje)
# print(w)
# print(b)    